﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturaTJPR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        WebBrowser WebBrowser1 = new WebBrowser();

        private void Form1_Load(object sender, EventArgs e)
        {
            //Não mostra erros de script caso tenha
            WebBrowser1.ScriptErrorsSuppressed = true;
            //Transforma a página web em um evento para ser carregada ao clicarmos no botão de captura
            WebBrowser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(this.dados_Carregados);
        }

        private void dados_Carregados(object sender, EventArgs e)
        {
            try
            {
                WebBrowser1.Document.GetElementById("searchButton").InvokeMember("click");

                var links = WebBrowser1.Document.GetElementsByTagName("a");
                int cont = 0;
                foreach (HtmlElement link in links)
                {
                    if (link.GetAttribute("className") == "even")
                    {
                        string linha = links[cont].ToString();
                    }
                    cont += 1;
                }
                //string text = WebBrowser1.DocumentText;
                //foreach (char a in text)
                //{
                //    if(a == "<")
                //    {

                //    }
                //}
            }
            catch (Exception ex)
            {

            }
        }


        private void button_captura_Click_1(object sender, EventArgs e)
        {
            WebBrowser1.Navigate("https://portal.tjpr.jus.br/e-dj/publico/diario/pesquisar.do");
        }
    }

}
